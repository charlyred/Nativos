/**
 * Clase Cuadrado.
 * 
 * @author Jose Luis S�nchez Ferrusca 
 * @version 1.1
 */
public class Cuadrado extends Punto
{
    private double Lado;
    
    public Cuadrado(int x, int y, double lado)
    {
        super(x,y);
        setLado(lado);
    }
    
    public void setLado(double lado)
    {
        Lado=(lado<0)?1:lado;
    }
    
    public double getLado()
    {
        return Lado;
    }
    
    public String toString()
    {
        return "Centro: " + super.toString()+ "; Lado -> " + this.getLado() ;
    }
}