
/**
 * Clase Punto
 * 
 * @author Jose Luis S�nchez Ferrusca 
 * @version 1.1
 */
public class Punto
{
	private int x,y;
	
	public Punto(int _x,int _y)
	{
	    setX(_x);
	    setY(_y);
	}
	
	public Punto()
	{
	    setX(1);
	    setY(1);
	}
	
	public void setX(int _x)
	{
	    x=_x;
	}
	
	public void setY(int _y)
	{
	    y=_y;
	}
	
	public int getX()
	{
	    return x;
	}
	
	public int getY()
	{
	    return y;
	}
	
	public String toString()
	{
	    return "[" + this.getX() + "," + this.getY() + "]";
	}   
}