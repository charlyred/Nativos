/**
 * Clase Cubo que hera los atributos y operaciones de la clase Cuadrado.
 * 
 * @author Jose Luis S�nchez Ferrusca 
 * @version 1.1
 */
public class CuboA 
{
    private double Altura;
    private CuadradoC Base;
    
    public CuboA(int x, int y, double lado, double altura)
    {
        Base=new CuadradoC(x,y,lado);
        setAltura(lado);
    }
    
    public void setAltura(double altura)
    {
        Altura=altura;
    }
    
    public double getAltura()
    {
        return Altura;
    }
    
    public void setBase(int x,int y, double lado)
    {
        Base.setArista(x,y);
        Base.setLado(lado);
    }
    
    public CuadradoC getBase()
    {
        return Base;
    }
        
    public String toString()
    {
        return "Base: [ " + Base.toString() + "]"  + " Altura --> " + this.getAltura();
    }
}