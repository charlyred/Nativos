
/**
 * Clase Cubo que hera los atributos y operaciones de la clase Cuadrado.
 * 
 * @author Jose Luis S�nchez Ferrusca 
 * @version 1.1
 */
public class Cubo extends Cuadrado
{
	private double Altura;
	public Cubo(int x, int y, double lado)
	{
	    super(x,y,lado);
	    setAltura(lado);
	}
	
	public void setAltura(double altura)
	{
	    Altura=altura;
	}
	
	public double getAltura()
	{
	    return Altura;
	}

	public String toString()
	{
	    return super.toString() + " Altura --> " + this.getAltura();
	}
}