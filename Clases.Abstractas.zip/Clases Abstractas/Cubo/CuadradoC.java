/**
 * Clase Cuadrado.
 * 
 * @author Jose Luis S�nchez Ferrusca 
 * @version 1.1
 */
public class CuadradoC 
{
    private double Lado;
    private Punto Arista;
    
    public CuadradoC(int x, int y, double lado)
    {
        Arista=new Punto(x,y);
        setLado(lado);
    }
    
    public void setLado(double lado)
    {
        Lado=(lado<0)?1:lado;
    }
    
    public void setArista(int x,int y)
    {
        Arista.setX(x);
        Arista.setY(y);
    }
    
    
    public Punto getArista()
    {
        return Arista;
    }
    
    public double getLado()
    {
        return Lado;
    }
    
    public String toString()
    {
        return "Centro: " + Arista.toString() + "; Lado -> " + this.getLado() ;
    }
   
}