
/**
 * Write a description of class Nomina here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Nomina
{    
    private Fecha FechaNomina;
    
    public Nomina(byte dia, byte mes, int a�o)
    {
        FechaNomina=new Fecha(dia, mes, a�o);
    }
    
    public double Salario(Empleado salario)
    { 
        if (FechaNomina.getMes()==salario.NacimientoMes())
            return salario.Ganancias()+100;
        else
            return salario.Ganancias();
    }
    
    public String toString(Empleado Datos_Empleado)
    {        
        return Datos_Empleado.toString();
    }
    
}
