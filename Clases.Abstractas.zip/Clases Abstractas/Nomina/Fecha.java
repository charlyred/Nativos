
/**
 * Este es una clase Fecha,  para guardar las fechas como 10/12/2006. 
 * Considerando todas las restricciones de la fecha: dias por mes, a�os bisiestos,
 * etc. La clase tiene diferentes representaciones de la fecha como los 
 * formatos dd/mm/aaaa o mm/dd/aaaa o aaaa/mm/dd o dia mes a�o.
 * 
 * @author Jose Luis Sanchez Ferrusca 
 * @version 1.0
 */
public class Fecha
{
    private byte Dia;
    private byte Mes;
    private int A�o;
    
    
    /** <<< Constructores  >>>
     *Se pueden crear el objeto fecha por medio de dos constructores, uno donde
     *  agrega automaticamente esta fecha 1/1/2006 o la que sea indicada
     * 
     */
    public Fecha()
    {
        setDia((byte)1);
        setMes((byte)1);
        setA�o(2006);
    }
    
    public Fecha(byte dia, byte mes, int a�o)
    {
        setDia(dia);
        setMes(mes);
        setA�o(a�o);
    }

    /** <<< Modificadores >>>
     *  En estos se modifican los atributos del objeto Fecha, que
     *  son el dia, mes y a�o
     */
    
     /** En este metodo se verifica que los dias correspondan deacuerdo al numero de dias que tenga determinado mes
     * adem�s adem�s de aumentar eel dia 29 si el a�o es bisiesto
     */
    public void setDia(byte dia)
    {

        if(Mes==1 || Mes ==3 || Mes == 5 || Mes == 7 || Mes == 8 || Mes ==10 || Mes==12) // El mes tiene 31 dias?
            Dia=(dia>0 && dia<32)?dia:1;
        else if (Mes == 2){ // Es Febrero??
            if (A�o%4==0) // Es A�o Biciesto??
                Dia=(dia>0 && dia<30)?dia:1;
            else  
                Dia=(dia>0 && dia<29)?dia:1;
        }
        else // El mes tiene 30 dias??
                Dia=(dia>0 && dia<31)?dia:1;
    }
    
        /** En el Metodo setMes se asigna el numero del mes correspondiente y se verifica que el numero de
         * mes exista, es decir del 1 al 12 y si al hacer el cambio del mes el dia no corresponde este cambia
         * a uno
         */    
    public void setMes(byte mes)
    {

        Mes=(mes>0 && mes <=12)?mes:1;
        setDia(Dia);

    }
    
    /** En el Metodo setA�o modifica el atributo A�o y verifica si es a�o biciesto para decidir si es una fecha
    * valida
    */
    public void setA�o(int a�o)
    {

        A�o=(a�o>0)?a�o:1;
        setDia(Dia);
    }
 
    public byte getMes()
    {
        return Mes;
    }
    
        /** DEvuelve la fecha en que se encuentra el objeto fecha, existen 4 tipos de fechas que puede regresar
         *  y esto depende de como el usuario desea mostrar la informacion
         *  dd/mm/aa, mm/dd/aa, aa/mm/dd o "Dia de Mes de A�o"
         */
    public String getFecha(byte tipo)
    {
        

        if (tipo==1)
            return Dia + "/" + Mes + "/" + A�o;
        else if (tipo==2)
            return Mes + "/" +Dia + "/" + A�o;
         else if (tipo==3)
            return A�o + "/"+ Mes + "/" + Dia ;
         else if (tipo==4){
             if (Mes ==1)
                return Dia + " de Enero de " + A�o;
             else if (Mes ==2)
                return Dia + " de Febrero de " + A�o;
             else if (Mes ==3)
                return Dia + " de Marzo de " + A�o;
             else if (Mes ==4)
                return Dia + " de Abril de " + A�o;
             else if (Mes==5)
                return Dia + " de Mayo de " + A�o;
             else if (Mes==6)
                return Dia + " de Junio de " + A�o;
             else if (Mes==7)
                return Dia + " de Julio de " + A�o;
             else if (Mes==8)
                return Dia + " de Agosto de " + A�o;
             else if (Mes==9)
                return Dia + " de Septiembre de " + A�o;
             else if (Mes==10)
                return Dia + " de Octubre de " + A�o;
             else if (Mes==11)
                return Dia + " de Noviembre de " + A�o;
             else if (Mes==12)
                return Dia + " de Diciembre de " + A�o;
            }
            return Dia + "/" + Mes + "/" + A�o;
   }                                     
}