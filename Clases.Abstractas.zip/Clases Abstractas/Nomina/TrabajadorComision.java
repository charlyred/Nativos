
/**
 * Write a description of class TrabajadorComision here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TrabajadorComision extends Empleado
{
	private double Salario, Comision;
	private int Piezas;

	/**
	 * Constructor for objects of class TrabajadorHoras
	 */
	public TrabajadorComision(String nombre, String apellido, double salario, double comision, int piezas, byte dia, byte mes, int a�o, int clave)
	{
		super(nombre,apellido, dia,mes,a�o,clave);
		setSalario(salario);
		setComision(comision);
		setPiezas(piezas);
	}

	/**
	 * An example of a method - replace this comment with your own
	 * 
	 * @param  y   a sample parameter for a method
	 * @return     the sum of x and y 
	 */
	public void setSalario(double salario)
	{
	    Salario=(salario>0?salario:0);
	}
	
	public void setComision(double comision)
	{
	    Comision=(comision<0)?1:comision;
	}
	
	public double Ganancias()
	{
	    return Salario+Comision*Piezas;
	}
	
    public void setPiezas(int piezas)
    {
        Piezas=(piezas<0)?1:piezas;
    }
	public String toString()
	{
	    return "Trabajador por Comisi�n: "+ getNombre()+' '+getApellido();
	} 
}
