
/**
 * Write a description of class Jefe here.
 * 
 * Trabajador por piezas y trabajador por comisi�n
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Jefe extends Empleado
{
    // instance variables - replace the example below with your own
    private double SalarioSemanal;

    /**
     * Constructor for objects of class Jefe
     */
    public Jefe(String nombre, String apellido, double s, byte dia, byte mes, int a�o, int clave)
    {
        super(nombre,apellido,dia,mes,a�o,clave);
        setSalarioSemanal(s);
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void setSalarioSemanal(double s)
    {
		SalarioSemanal=(s>0?s:0);
	}
	
	public double Ganancias()
	{
	    return SalarioSemanal;
	}
	
	public String toString()
	{
	    return "Jefe: " + getNombre() + ' ' + getApellido();
	}   
}