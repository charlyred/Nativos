
/**
 * Write a description of class TrabajadorPieza here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TrabajadorPieza extends Empleado
{
    private double Precio;
    private int Piezas;
    /**
     * Constructor for objects of class TrabajadorHoras
     */
    public TrabajadorPieza(String nombre, String apellido, double precio, int piezas, byte dia, byte mes, int a�o, int clave)
    {
        super(nombre,apellido,dia,mes,a�o,clave);
        setPrecio(precio);
        setPiezas(piezas);
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void setPrecio(double precio)
    {
        Precio=(precio>0?precio:0);
    }
    
    public void setPiezas(int piezas)
    {
        Piezas=(piezas<0)?1:piezas;
    }
    
    public double Ganancias()
    {
        return Precio*Piezas;
    }
    
    public String toString()
    {
        return "Trabajador por Piezas: "+ getNombre()+' '+getApellido();
    } 
}
