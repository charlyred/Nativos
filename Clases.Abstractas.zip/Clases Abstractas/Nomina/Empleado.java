
/**
 * Abstract class Empleado - write a description of the class here
 * 
 * @author (your name here)
 * @version (version number or date here)
 */
public abstract class Empleado
{
    private String Nombre, Apellido;
    private Fecha FechaNacimiento;
    private int ClaveDepartamento;
    
    public Empleado(String nombre, String apellido, byte dia, byte mes, int a�o, int clave)
    {
        Nombre =new String(nombre);
        Apellido= new String (apellido);
        FechaNacimiento= new Fecha(dia,mes,a�o);
        ClaveDepartamento=clave;
    }
    
    public String getNombre()
    {
        return new String(Nombre);
    }
       
    public String getApellido()
    {
        return new String(Apellido);
    }
    
    public Fecha getFechaNacimiento()
    {
        return FechaNacimiento;
    }
    
    public byte NacimientoMes()
    {
        return FechaNacimiento.getMes();
    }
    
    public int getClaveDepartamento()
    {
        return ClaveDepartamento;
    }
    
    abstract double Ganancias();   
}
