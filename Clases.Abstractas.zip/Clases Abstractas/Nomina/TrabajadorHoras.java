
/**
 * Write a description of class TrabajadorHoras here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TrabajadorHoras extends Empleado
{
	private double Salario, Horas;

	/**
	 * Constructor for objects of class TrabajadorHoras
	 */
	public TrabajadorHoras(String nombre, String apellido, double salario, double horas, byte dia, byte mes, int a�o, int clave)
	{
		super(nombre,apellido,dia,mes,a�o,clave);
		setSalario(salario);
		setHoras(horas);
	}

	/**
	 * An example of a method - replace this comment with your own
	 * 
	 * @param  y   a sample parameter for a method
	 * @return     the sum of x and y 
	 */
	public void setSalario(double salario)
	{
	    Salario=(salario>0?salario:0);
	}
	
	public void setHoras(double horas)
	{
	    Horas=(horas>=0 && horas<168?horas:0);
	}
	
	public double Ganancias()
	{
	    return Salario*Horas;
	}
	
	public String toString()
	{
	    return "Trabajador por Horas: "+ getNombre()+' '+getApellido();
	}   
}
